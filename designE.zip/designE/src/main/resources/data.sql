INSERT INTO BRUGER(brugernavn, adgangskode) VALUES ('Henrik', 'hej');

INSERT INTO BRUGER(brugernavn, adgangskode) VALUES ('Christian', 'hej');

INSERT INTO BRUGER(brugernavn, adgangskode) VALUES ('Mille', 'hej');

INSERT INTO ANSATTE_TYPE VALUES ( 1, 'pro', 'pro' );


INSERT INTO KUNDE VALUES  (1, 'Lygten 37', 'Nørrebro','Videregående uddannelse','kea@hotmail.com','Kea.dk','84638264','KEA', '34636346');

INSERT INTO ANSAT VALUES ( 1,'Peter bangs vej 67', 'Frederiksberg', '1994-04-10 00:00:00', 'Bendtsen',
'Chri@hotmail.com', 'Christian', 'cb', 'MAND', 'Single', '67849340', 'null', '486939274', 'hr', '7564567234',  '2020-05-29 00:00:00', 1 );